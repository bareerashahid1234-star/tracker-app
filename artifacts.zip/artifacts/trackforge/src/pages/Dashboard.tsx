import { motion } from "framer-motion";
import { Link } from "wouter";
import { BarChart3, Flame, ListTodo, Plus, TrendingUp, Zap } from "lucide-react";
import { useGetDashboardSummary, useListTrackers } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import type { Tracker, ActivityEntry } from "@workspace/api-client-react";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.07 } },
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  color,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon: React.ElementType;
  color: string;
}) {
  return (
    <motion.div
      variants={item}
      className="rounded-2xl border border-border/60 bg-card p-5 flex flex-col gap-3 hover:border-primary/30 transition-colors"
    >
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${color}`}>
        <Icon className="w-4.5 h-4.5" />
      </div>
      <div>
        <div className="text-2xl font-bold">{value}</div>
        <div className="text-sm text-muted-foreground">{label}</div>
        {sub && <div className="text-xs text-muted-foreground/70 mt-0.5">{sub}</div>}
      </div>
    </motion.div>
  );
}

function TrackerCard({ tracker }: { tracker: Tracker }) {
  const pct = tracker.todayCompletionPct ?? 0;
  return (
    <Link href={`/trackers/${tracker.id}`}>
      <motion.div
        variants={item}
        className="rounded-xl border border-border/60 bg-card p-4 hover:border-primary/40 hover:bg-card/80 transition-all cursor-pointer group"
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <span className="text-xl">{tracker.icon}</span>
            <div>
              <div className="font-medium text-sm leading-tight">{tracker.title}</div>
              {tracker.category && (
                <div className="text-xs text-muted-foreground">{tracker.category}</div>
              )}
            </div>
          </div>
          {tracker.currentStreak && tracker.currentStreak > 0 ? (
            <Badge className="bg-orange-500/10 text-orange-400 border-orange-500/20 text-xs">
              🔥 {tracker.currentStreak}d
            </Badge>
          ) : null}
        </div>
        <div className="space-y-1">
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>Today</span>
            <span>{Math.round(pct)}%</span>
          </div>
          <Progress value={pct} className="h-1.5" />
        </div>
      </motion.div>
    </Link>
  );
}

function ActivityFeed({ entries }: { entries: ActivityEntry[] }) {
  if (!entries.length) {
    return <div className="text-sm text-muted-foreground text-center py-8">No activity yet — start logging!</div>;
  }
  return (
    <div className="space-y-2">
      {entries.map((e, i) => (
        <div key={i} className="flex items-center justify-between py-2 border-b border-border/40 last:border-0">
          <div>
            <div className="text-sm font-medium">{e.trackerTitle}</div>
            <div className="text-xs text-muted-foreground">{new Date(e.date).toLocaleDateString()}</div>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-sm font-semibold text-primary">{Math.round(e.completionPct)}%</div>
            <div className="w-16 h-1.5 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full bg-primary rounded-full"
                style={{ width: `${e.completionPct}%` }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const { data: summary, isLoading: summaryLoading } = useGetDashboardSummary();
  const { data: trackers, isLoading: trackersLoading } = useListTrackers();

  const pinned = trackers?.filter((t) => t.isPinned) ?? [];
  const recent = trackers?.slice(0, 6) ?? [];
  const displayed = pinned.length > 0 ? pinned : recent;

  return (
    <motion.div initial="hidden" animate="show" variants={container} className="space-y-8">
      {/* Header */}
      <motion.div variants={item} className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-0.5">
            {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
          </p>
        </div>
        <Link href="/trackers/new">
          <Button size="sm" className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
            <Plus className="w-4 h-4 mr-1.5" /> New Tracker
          </Button>
        </Link>
      </motion.div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryLoading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-2xl" />
          ))
        ) : (
          <>
            <StatCard
              label="Active trackers"
              value={summary?.totalTrackers ?? 0}
              icon={ListTodo}
              color="bg-primary/10 text-primary"
            />
            <StatCard
              label="Today's completion"
              value={`${Math.round(summary?.todayCompletionPct ?? 0)}%`}
              sub={`${summary?.activeToday ?? 0} active`}
              icon={TrendingUp}
              color="bg-green-500/10 text-green-400"
            />
            <StatCard
              label="Current streak"
              value={`${summary?.currentStreak ?? 0}d`}
              sub={`Best: ${summary?.longestStreak ?? 0}d`}
              icon={Flame}
              color="bg-orange-500/10 text-orange-400"
            />
            <StatCard
              label="Productivity score"
              value={summary?.productivityScore ?? 0}
              sub={`${Math.round(summary?.weeklyCompletionPct ?? 0)}% this week`}
              icon={Zap}
              color="bg-purple-500/10 text-purple-400"
            />
          </>
        )}
      </div>

      {/* Trackers + Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trackers */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-lg">
              {pinned.length > 0 ? "Pinned Trackers" : "Your Trackers"}
            </h2>
            <Link href="/trackers">
              <Button variant="ghost" size="sm" className="text-muted-foreground text-xs">
                View all →
              </Button>
            </Link>
          </div>
          {trackersLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-24 rounded-xl" />
              ))}
            </div>
          ) : displayed.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border/60 p-12 text-center">
              <ListTodo className="w-10 h-10 mx-auto mb-3 text-muted-foreground/40" />
              <div className="text-muted-foreground text-sm mb-4">No trackers yet</div>
              <Link href="/trackers/new">
                <Button size="sm" variant="outline">
                  <Plus className="w-4 h-4 mr-1.5" /> Create your first tracker
                </Button>
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {displayed.map((t) => (
                <TrackerCard key={t.id} tracker={t} />
              ))}
            </div>
          )}
        </div>

        {/* Activity */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-lg">Recent Activity</h2>
            <Link href="/analytics">
              <Button variant="ghost" size="sm" className="text-muted-foreground text-xs gap-1">
                <BarChart3 className="w-3.5 h-3.5" /> Analytics
              </Button>
            </Link>
          </div>
          <div className="rounded-2xl border border-border/60 bg-card p-4">
            {summaryLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 rounded" />
                ))}
              </div>
            ) : (
              <ActivityFeed entries={summary?.recentActivity ?? []} />
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
