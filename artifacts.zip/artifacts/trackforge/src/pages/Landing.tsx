import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BarChart3, CheckCircle2, Flame, ListTodo, Share2, Sparkles, TrendingUp, Zap } from "lucide-react";

const features = [
  {
    icon: ListTodo,
    title: "Custom Trackers",
    description: "Build habit grids, task lists, and goal trackers tailored to your exact workflow.",
  },
  {
    icon: Flame,
    title: "Streak Engine",
    description: "Stay motivated with automatic streak tracking and milestone celebrations.",
  },
  {
    icon: BarChart3,
    title: "Deep Analytics",
    description: "Visualize your progress over time with interactive charts and completion rates.",
  },
  {
    icon: Share2,
    title: "Share & Collaborate",
    description: "Share public tracker links or invite others to collaborate on your goals.",
  },
  {
    icon: TrendingUp,
    title: "Productivity Score",
    description: "A live score that reflects your consistency across all active trackers.",
  },
  {
    icon: Zap,
    title: "Daily Dashboard",
    description: "One glance to see everything — pinned trackers, today's tasks, streaks.",
  },
];

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Nav */}
      <nav className="fixed top-0 inset-x-0 z-50 h-16 flex items-center justify-between px-6 lg:px-12 border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-primary" />
          </div>
          <span className="font-bold text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-400">
            TrackForge
          </span>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/sign-in">
            <Button variant="ghost" size="sm">Sign in</Button>
          </Link>
          <Link href="/sign-up">
            <Button size="sm" className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
              Get started free
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-6 lg:px-12 relative">
        {/* Glow orbs */}
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-primary/8 rounded-full blur-[140px] pointer-events-none" />
        <div className="absolute top-40 left-1/4 w-[400px] h-[400px] bg-purple-500/5 rounded-full blur-[100px] pointer-events-none" />

        <motion.div
          className="max-w-4xl mx-auto text-center relative"
          initial="hidden"
          animate="show"
          variants={container}
        >
          <motion.div variants={item} className="mb-6">
            <Badge className="bg-primary/10 text-primary border-primary/20 px-4 py-1.5 text-sm">
              <Sparkles className="w-3.5 h-3.5 mr-1.5" />
              Productivity, forged your way
            </Badge>
          </motion.div>

          <motion.h1
            variants={item}
            className="text-5xl lg:text-7xl font-extrabold tracking-tight mb-6 leading-[1.08]"
          >
            Track anything.{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-br from-primary via-purple-400 to-violet-300">
              Build everything.
            </span>
          </motion.h1>

          <motion.p
            variants={item}
            className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            TrackForge is a premium productivity platform that lets you create custom habit trackers, goal grids, and task systems — then gives you the analytics to actually improve.
          </motion.p>

          <motion.div variants={item} className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/sign-up">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 shadow-xl shadow-primary/25 text-base px-8 h-12"
              >
                Start for free
              </Button>
            </Link>
            <Link href="/sign-in">
              <Button size="lg" variant="outline" className="text-base px-8 h-12">
                Sign in
              </Button>
            </Link>
          </motion.div>

          {/* Social proof */}
          <motion.div variants={item} className="mt-14 flex items-center justify-center gap-8 text-sm text-muted-foreground">
            {[
              { icon: CheckCircle2, text: "No credit card required" },
              { icon: CheckCircle2, text: "Free forever tier" },
              { icon: CheckCircle2, text: "Cancel anytime" },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-2">
                <Icon className="w-4 h-4 text-primary" />
                {text}
              </div>
            ))}
          </motion.div>
        </motion.div>

        {/* Dashboard preview */}
        <motion.div
          className="max-w-5xl mx-auto mt-20 relative"
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <div className="rounded-2xl border border-border/60 bg-card/40 backdrop-blur-sm overflow-hidden shadow-2xl shadow-black/40">
            <div className="h-10 bg-card/80 border-b border-border/50 flex items-center gap-2 px-4">
              <div className="w-3 h-3 rounded-full bg-destructive/60" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/60" />
              <div className="w-3 h-3 rounded-full bg-green-500/60" />
              <div className="ml-4 flex-1 h-5 rounded bg-muted/50 max-w-xs" />
            </div>
            <div className="p-8 grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Trackers", value: "12", color: "text-primary" },
                { label: "Today", value: "87%", color: "text-green-400" },
                { label: "Streak", value: "23d", color: "text-orange-400" },
                { label: "Score", value: "94", color: "text-purple-400" },
              ].map(({ label, value, color }) => (
                <div key={label} className="rounded-xl bg-card border border-border/50 p-4 text-center">
                  <div className={`text-3xl font-bold ${color} mb-1`}>{value}</div>
                  <div className="text-xs text-muted-foreground">{label}</div>
                </div>
              ))}
            </div>
            <div className="px-8 pb-8 grid grid-cols-1 md:grid-cols-3 gap-4">
              {["Morning Routine", "Deep Work", "Fitness Goals"].map((name, i) => (
                <div key={name} className="rounded-xl bg-card border border-border/50 p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium">{name}</span>
                    <span className="text-xs text-muted-foreground">{[5, 3, 4][i]} items</span>
                  </div>
                  <div className="flex gap-1">
                    {Array.from({ length: 7 }).map((_, j) => (
                      <div
                        key={j}
                        className={`flex-1 h-6 rounded-sm ${j < [5, 3, 6][i] ? "bg-primary/70" : "bg-muted/40"}`}
                      />
                    ))}
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground">{[72, 43, 85][i]}% this week</div>
                </div>
              ))}
            </div>
          </div>
          <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-background to-transparent pointer-events-none" />
        </motion.div>
      </section>

      {/* Features */}
      <section className="py-24 px-6 lg:px-12">
        <div className="max-w-6xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-4xl font-bold mb-4">Everything you need to build better habits</h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              A full-featured productivity system, not another to-do app.
            </p>
          </motion.div>
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            variants={container}
          >
            {features.map(({ icon: Icon, title, description }) => (
              <motion.div
                key={title}
                variants={item}
                className="rounded-2xl border border-border/50 bg-card/40 p-6 hover:bg-card/80 hover:border-primary/30 transition-all duration-300 group"
              >
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">{title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6 lg:px-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-primary/10 rounded-full blur-[100px] pointer-events-none" />
        <motion.div
          className="max-w-2xl mx-auto text-center relative"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl font-bold mb-4">Ready to forge your habits?</h2>
          <p className="text-muted-foreground text-lg mb-8">
            Join thousands building better systems. Start free, upgrade when you're ready.
          </p>
          <Link href="/sign-up">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 shadow-xl shadow-primary/25 text-base px-10 h-12"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Get started — it's free
            </Button>
          </Link>
        </motion.div>
      </section>

      <footer className="border-t border-border/50 py-8 px-6 lg:px-12 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} TrackForge. Built to help you focus.
      </footer>
    </div>
  );
}
