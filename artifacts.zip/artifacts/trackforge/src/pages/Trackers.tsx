import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link, useLocation } from "wouter";
import { Flame, Grid, List, ListTodo, MoreHorizontal, Pin, Plus, Search, Trash2 } from "lucide-react";
import {
  useListTrackers,
  useDeleteTracker,
  useUpdateTracker,
  getListTrackersQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { Tracker } from "@workspace/api-client-react";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.06 } },
};
const item = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35 } },
};

const modeColors: Record<string, string> = {
  daily: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  weekly: "bg-violet-500/10 text-violet-400 border-violet-500/20",
  monthly: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
};

function TrackerCard({
  tracker,
  onDelete,
  onTogglePin,
}: {
  tracker: Tracker;
  onDelete: (id: number) => void;
  onTogglePin: (tracker: Tracker) => void;
}) {
  const [, navigate] = useLocation();
  const pct = tracker.todayCompletionPct ?? 0;
  return (
    <motion.div
      variants={item}
      layout
      className="rounded-2xl border border-border/60 bg-card p-5 hover:border-primary/30 transition-all group relative cursor-pointer"
      onClick={() => navigate(`/trackers/${tracker.id}`)}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
            style={{ backgroundColor: `${tracker.color}20`, border: `1px solid ${tracker.color}40` }}
          >
            {tracker.icon}
          </div>
          <div className="min-w-0">
            <div className="font-semibold leading-tight flex items-center gap-1.5">
              {tracker.title}
              {tracker.isPinned && <Pin className="w-3 h-3 text-primary flex-shrink-0" />}
            </div>
            {tracker.description && (
              <div className="text-xs text-muted-foreground mt-0.5 truncate max-w-[180px]">
                {tracker.description}
              </div>
            )}
          </div>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={(e) => e.stopPropagation()}
            >
              <MoreHorizontal className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuItem onClick={(e) => { e.stopPropagation(); navigate(`/trackers/${tracker.id}/edit`); }}>
              Edit tracker
            </DropdownMenuItem>
            <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onTogglePin(tracker); }}>
              <Pin className="w-4 h-4 mr-2" />
              {tracker.isPinned ? "Unpin" : "Pin to dashboard"}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="text-destructive focus:text-destructive"
              onClick={(e) => { e.stopPropagation(); onDelete(tracker.id); }}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="flex items-center gap-2 mb-3">
        <Badge className={`text-xs ${modeColors[tracker.mode] ?? ""}`}>{tracker.mode}</Badge>
        {tracker.category && (
          <Badge variant="outline" className="text-xs">{tracker.category}</Badge>
        )}
        {tracker.currentStreak && tracker.currentStreak > 0 ? (
          <Badge className="bg-orange-500/10 text-orange-400 border-orange-500/20 text-xs ml-auto">
            <Flame className="w-3 h-3 mr-1" />{tracker.currentStreak}d
          </Badge>
        ) : null}
      </div>

      <div className="space-y-1.5">
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>{tracker.itemCount ?? 0} items</span>
          <span>Today: {Math.round(pct)}%</span>
        </div>
        <Progress value={pct} className="h-1.5" />
      </div>
    </motion.div>
  );
}

export default function Trackers() {
  const [search, setSearch] = useState("");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const queryClient = useQueryClient();

  const { data: trackers = [], isLoading } = useListTrackers({ search: search || undefined });
  const deleteMutation = useDeleteTracker();
  const updateMutation = useUpdateTracker();

  const handleDelete = () => {
    if (deleteId == null) return;
    deleteMutation.mutate(
      { id: deleteId },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListTrackersQueryKey() });
          setDeleteId(null);
        },
      }
    );
  };

  const handleTogglePin = (tracker: Tracker) => {
    updateMutation.mutate(
      { id: tracker.id, data: { isPinned: !tracker.isPinned } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListTrackersQueryKey() }) }
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-2xl font-bold">Trackers</h1>
          <p className="text-muted-foreground text-sm mt-0.5">{trackers.length} trackers total</p>
        </div>
        <Link href="/trackers/new">
          <Button size="sm" className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
            <Plus className="w-4 h-4 mr-1.5" /> New Tracker
          </Button>
        </Link>
      </motion.div>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="flex items-center gap-3"
      >
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search trackers…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex items-center gap-1 ml-auto">
          <Button
            variant={view === "grid" ? "secondary" : "ghost"}
            size="sm"
            className="h-9 w-9 p-0"
            onClick={() => setView("grid")}
          >
            <Grid className="w-4 h-4" />
          </Button>
          <Button
            variant={view === "list" ? "secondary" : "ghost"}
            size="sm"
            className="h-9 w-9 p-0"
            onClick={() => setView("list")}
          >
            <List className="w-4 h-4" />
          </Button>
        </div>
      </motion.div>

      {/* Trackers grid/list */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-40 rounded-2xl" />
          ))}
        </div>
      ) : trackers.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border/60 p-16 text-center">
          <ListTodo className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
          <div className="text-muted-foreground mb-5">
            {search ? "No trackers match your search" : "No trackers yet — create your first one"}
          </div>
          {!search && (
            <Link href="/trackers/new">
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" /> Create tracker
              </Button>
            </Link>
          )}
        </div>
      ) : (
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial="hidden"
            animate="show"
            variants={container}
            className={
              view === "grid"
                ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
                : "flex flex-col gap-3"
            }
          >
            {trackers.map((t) => (
              <TrackerCard
                key={t.id}
                tracker={t}
                onDelete={setDeleteId}
                onTogglePin={handleTogglePin}
              />
            ))}
          </motion.div>
        </AnimatePresence>
      )}

      {/* Delete confirmation */}
      <AlertDialog open={deleteId != null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Tracker</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the tracker and all its items and completion history. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive hover:bg-destructive/90"
              onClick={handleDelete}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
