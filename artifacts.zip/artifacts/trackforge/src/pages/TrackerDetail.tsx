import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link, useRoute } from "wouter";
import {
  ArrowLeft,
  CheckCircle2,
  Circle,
  ChevronDown,
  ChevronRight,
  Copy,
  Flame,
  GripVertical,
  Link as LinkIcon,
  Pencil,
  Plus,
  Settings2,
  Trash2,
  X,
  LayoutGrid,
  CheckSquare,
  TrendingUp,
  FileText,
  Hash,
  Timer,
  BarChart3,
  Sparkles,
} from "lucide-react";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { KeyboardSensor } from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import {
  useGetTracker,
  useListTrackerItems,
  useGetCompletionLog,
  useToggleCompletion,
  useCreateTrackerItem,
  useDeleteTrackerItem,
  useListSections,
  useCreateSection,
  useUpdateSection,
  useDeleteSection,
  useReorderSections,
  useCreateShareLink,
  useDeleteShareLink,
  getListTrackerItemsQueryKey,
  getGetCompletionLogQueryKey,
  getGetTrackerQueryKey,
  getListSectionsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import type { TrackerItem, Completion, TrackerSection } from "@workspace/api-client-react";

// ─── Constants ─────────────────────────────────────────────────────────────

const today = () => new Date().toISOString().split("T")[0];

const LAYOUT_META: Record<string, { label: string; Icon: any; color: string }> = {
  habit_grid: { label: "Habit Grid", Icon: LayoutGrid, color: "#9333ea" },
  checkbox: { label: "Checklist", Icon: CheckSquare, color: "#3b82f6" },
  progress: { label: "Progress", Icon: TrendingUp, color: "#10b981" },
  notes: { label: "Notes", Icon: FileText, color: "#f59e0b" },
  counter: { label: "Counter", Icon: Hash, color: "#ec4899" },
  streak: { label: "Streak", Icon: Flame, color: "#f97316" },
  timer: { label: "Timer", Icon: Timer, color: "#6366f1" },
};

const SECTION_ICONS = ["📋", "📚", "💪", "💰", "🧠", "😴", "🧘", "🎯", "🚀", "🌱", "💧", "🎨", "🏃", "🍎", "📝", "⭐", "🔥", "🌙", "☀️", "🎵"];

const SECTION_COLORS = [
  "#9333ea", "#3b82f6", "#10b981", "#f59e0b",
  "#ec4899", "#f97316", "#6366f1", "#14b8a6",
  "#ef4444", "#84cc16",
];

// ─── Habit Grid Layout ─────────────────────────────────────────────────────

function HabitGrid({ items, completions, trackerId }: {
  items: TrackerItem[];
  completions: Completion[];
  trackerId: number;
}) {
  const queryClient = useQueryClient();
  const toggle = useToggleCompletion();
  const completionMap = new Map<string, boolean>();
  completions.forEach(c => completionMap.set(`${c.itemId}-${c.date}`, c.completed));

  const todayStr = today();
  const last14 = Array.from({ length: 14 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (13 - i));
    return d.toISOString().split("T")[0];
  });

  const handleToggle = (itemId: number, date: string, current: boolean) => {
    toggle.mutate(
      { trackerId, data: { itemId, date, completed: !current } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCompletionLogQueryKey(trackerId) }) }
    );
  };

  if (items.length === 0) return <EmptyItems />;

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[480px]">
        <div className="flex items-center mb-2 ml-[160px] gap-1">
          {last14.map(d => (
            <div key={d} className={`w-7 text-center text-[10px] flex-shrink-0 ${d === todayStr ? "text-primary font-bold" : "text-muted-foreground"}`}>
              {new Date(d + "T12:00:00").toLocaleDateString("en-US", { weekday: "narrow" })}
            </div>
          ))}
        </div>
        {items.map(item => (
          <div key={item.id} className="flex items-center gap-1 mb-1">
            <div className="w-[152px] flex-shrink-0 pr-2 text-sm text-muted-foreground truncate text-right">{item.name}</div>
            {last14.map(d => {
              const done = completionMap.get(`${item.id}-${d}`) ?? false;
              const isToday = d === todayStr;
              return (
                <button key={d} onClick={() => handleToggle(item.id, d, done)}
                  className={`w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0 transition-all duration-150 ${
                    done ? "bg-primary/80 hover:bg-primary" : isToday
                      ? "bg-muted/60 hover:bg-primary/20 border border-primary/30"
                      : "bg-muted/30 hover:bg-muted/60 border border-border/30"
                  }`}
                >
                  {done ? <CheckCircle2 className="w-3.5 h-3.5 text-white" /> : <Circle className={`w-3 h-3 ${isToday ? "text-primary/40" : "text-muted-foreground/25"}`} />}
                </button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Checkbox Layout ───────────────────────────────────────────────────────

function CheckboxLayout({ items, completions, trackerId }: {
  items: TrackerItem[];
  completions: Completion[];
  trackerId: number;
}) {
  const queryClient = useQueryClient();
  const toggle = useToggleCompletion();
  const todayStr = today();
  const doneToday = new Set(completions.filter(c => c.date === todayStr && c.completed).map(c => c.itemId));

  const handleToggle = (itemId: number) => {
    const done = doneToday.has(itemId);
    toggle.mutate(
      { trackerId, data: { itemId, date: todayStr, completed: !done } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCompletionLogQueryKey(trackerId) }) }
    );
  };

  if (items.length === 0) return <EmptyItems />;

  const completedCount = items.filter(i => doneToday.has(i.id)).length;

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs text-muted-foreground">Today's checklist</span>
        <span className="text-xs font-medium">{completedCount}/{items.length}</span>
      </div>
      <div className="space-y-1.5">
        {items.map(item => {
          const done = doneToday.has(item.id);
          return (
            <button key={item.id} onClick={() => handleToggle(item.id)}
              className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted/40 transition-colors group text-left"
            >
              <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-all ${done ? "bg-primary border-primary" : "border-border group-hover:border-primary/50"}`}>
                {done && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
              </div>
              <span className={`text-sm flex-1 ${done ? "line-through text-muted-foreground" : ""}`}>{item.name}</span>
              {item.description && <span className="text-xs text-muted-foreground truncate max-w-[120px]">{item.description}</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─── Progress Layout ───────────────────────────────────────────────────────

function ProgressLayout({ items, completions, trackerId }: {
  items: TrackerItem[];
  completions: Completion[];
  trackerId: number;
}) {
  const queryClient = useQueryClient();
  const toggle = useToggleCompletion();
  const [editing, setEditing] = useState<Record<number, string>>({});
  const todayStr = today();

  const todayValues = new Map<number, number>();
  completions.filter(c => c.date === todayStr).forEach(c => {
    if (c.value !== null && c.value !== undefined) todayValues.set(c.itemId, c.value);
  });

  const handleSet = (itemId: number, rawVal: string) => {
    const val = parseFloat(rawVal);
    if (isNaN(val)) return;
    toggle.mutate(
      { trackerId, data: { itemId, date: todayStr, completed: val > 0, value: val } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCompletionLogQueryKey(trackerId) }) }
    );
  };

  if (items.length === 0) return <EmptyItems />;

  return (
    <div className="space-y-4">
      {items.map(item => {
        const current = todayValues.get(item.id) ?? 0;
        const target = item.targetValue ?? 100;
        const pct = Math.min((current / target) * 100, 100);

        return (
          <div key={item.id} className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{item.name}</span>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  value={editing[item.id] ?? current}
                  onChange={e => setEditing(p => ({ ...p, [item.id]: e.target.value }))}
                  onBlur={e => { handleSet(item.id, e.target.value); setEditing(p => { const n = { ...p }; delete n[item.id]; return n; }); }}
                  onKeyDown={e => { if (e.key === "Enter") { handleSet(item.id, (editing[item.id] ?? String(current))); e.currentTarget.blur(); } }}
                  className="w-16 h-7 text-xs text-right bg-muted/40 border border-border/50 rounded-md px-2 focus:outline-none focus:border-primary/50"
                />
                <span className="text-xs text-muted-foreground">/ {target} {item.unit ?? ""}</span>
              </div>
            </div>
            <div className="h-2 rounded-full bg-muted/40 overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-primary"
                initial={{ width: 0 }}
                animate={{ width: `${pct}%` }}
                transition={{ duration: 0.4 }}
              />
            </div>
            <div className="text-xs text-muted-foreground text-right">{Math.round(pct)}%</div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Counter Layout ────────────────────────────────────────────────────────

function CounterLayout({ items, completions, trackerId }: {
  items: TrackerItem[];
  completions: Completion[];
  trackerId: number;
}) {
  const queryClient = useQueryClient();
  const toggle = useToggleCompletion();
  const todayStr = today();

  const todayValues = new Map<number, number>();
  completions.filter(c => c.date === todayStr).forEach(c => {
    if (c.value !== null && c.value !== undefined) todayValues.set(c.itemId, c.value);
  });

  const adjust = (itemId: number, delta: number) => {
    const current = todayValues.get(itemId) ?? 0;
    const next = Math.max(0, current + delta);
    toggle.mutate(
      { trackerId, data: { itemId, date: todayStr, completed: next > 0, value: next } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCompletionLogQueryKey(trackerId) }) }
    );
  };

  if (items.length === 0) return <EmptyItems />;

  return (
    <div className="grid grid-cols-2 gap-3">
      {items.map(item => {
        const value = todayValues.get(item.id) ?? 0;
        return (
          <div key={item.id} className="bg-muted/30 rounded-xl p-4 flex flex-col items-center gap-2">
            <div className="text-xs text-muted-foreground text-center truncate w-full text-center">{item.name}</div>
            <div className="text-3xl font-bold tabular-nums">{value}</div>
            {item.unit && <div className="text-xs text-muted-foreground">{item.unit}</div>}
            <div className="flex items-center gap-2">
              <button onClick={() => adjust(item.id, -1)}
                className="w-8 h-8 rounded-full bg-muted hover:bg-muted/80 flex items-center justify-center text-lg font-bold leading-none transition-colors">−</button>
              <button onClick={() => adjust(item.id, 1)}
                className="w-8 h-8 rounded-full bg-primary/20 hover:bg-primary/30 flex items-center justify-center text-lg font-bold text-primary leading-none transition-colors">+</button>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Notes Layout ─────────────────────────────────────────────────────────

function NotesLayout({ items }: { items: TrackerItem[] }) {
  if (items.length === 0) return <EmptyItems />;
  return (
    <div className="space-y-3">
      {items.map(item => (
        <div key={item.id} className="rounded-xl border border-border/50 bg-muted/20 p-3">
          <div className="text-sm font-medium mb-1">{item.name}</div>
          {item.description && <div className="text-sm text-muted-foreground whitespace-pre-wrap">{item.description}</div>}
        </div>
      ))}
    </div>
  );
}

// ─── Streak Layout ────────────────────────────────────────────────────────

function StreakLayout({ items, completions, trackerId }: {
  items: TrackerItem[];
  completions: Completion[];
  trackerId: number;
}) {
  const queryClient = useQueryClient();
  const toggle = useToggleCompletion();
  const todayStr = today();
  const doneToday = new Set(completions.filter(c => c.date === todayStr && c.completed).map(c => c.itemId));

  const getStreak = (itemId: number) => {
    let streak = 0;
    for (let i = 0; i < 365; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const ds = d.toISOString().split("T")[0];
      const done = completions.some(c => c.itemId === itemId && c.date === ds && c.completed);
      if (done) streak++;
      else break;
    }
    return streak;
  };

  const handleToggle = (itemId: number) => {
    const done = doneToday.has(itemId);
    toggle.mutate(
      { trackerId, data: { itemId, date: todayStr, completed: !done } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCompletionLogQueryKey(trackerId) }) }
    );
  };

  if (items.length === 0) return <EmptyItems />;

  return (
    <div className="space-y-3">
      {items.map(item => {
        const streak = getStreak(item.id);
        const done = doneToday.has(item.id);
        return (
          <div key={item.id} className="flex items-center gap-3 p-3 rounded-xl bg-muted/30 hover:bg-muted/40 transition-colors">
            <button onClick={() => handleToggle(item.id)}
              className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 text-lg transition-all ${done ? "bg-orange-500 shadow-lg shadow-orange-500/30" : "bg-muted/60 border border-border"}`}
            >
              {done ? "🔥" : "⭕"}
            </button>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium">{item.name}</div>
              <div className="text-xs text-muted-foreground">{done ? "Done today!" : "Not done yet"}</div>
            </div>
            <div className="text-right flex-shrink-0">
              <div className="text-xl font-bold text-orange-400">{streak}</div>
              <div className="text-xs text-muted-foreground">day streak</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Timer Layout ─────────────────────────────────────────────────────────

function TimerLayout({ items, completions, trackerId }: {
  items: TrackerItem[];
  completions: Completion[];
  trackerId: number;
}) {
  const queryClient = useQueryClient();
  const toggle = useToggleCompletion();
  const [running, setRunning] = useState<Record<number, number | null>>({});
  const [elapsed, setElapsed] = useState<Record<number, number>>({});
  const intervals = useRef<Record<number, ReturnType<typeof setInterval>>>({});
  const todayStr = today();

  const todayMinutes = new Map<number, number>();
  completions.filter(c => c.date === todayStr).forEach(c => {
    if (c.value) todayMinutes.set(c.itemId, c.value);
  });

  const startTimer = (itemId: number) => {
    const start = Date.now() - (elapsed[itemId] ?? 0) * 1000;
    setRunning(p => ({ ...p, [itemId]: start }));
    intervals.current[itemId] = setInterval(() => {
      setElapsed(p => ({ ...p, [itemId]: Math.floor((Date.now() - start) / 1000) }));
    }, 1000);
  };

  const stopTimer = (itemId: number) => {
    clearInterval(intervals.current[itemId]);
    setRunning(p => { const n = { ...p }; delete n[itemId]; return n; });
    const mins = Math.max(1, Math.round((elapsed[itemId] ?? 0) / 60));
    const prev = todayMinutes.get(itemId) ?? 0;
    toggle.mutate(
      { trackerId, data: { itemId, date: todayStr, completed: true, value: prev + mins } },
      { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetCompletionLogQueryKey(trackerId) }); setElapsed(p => { const n = { ...p }; delete n[itemId]; return n; }); } }
    );
  };

  const fmtSec = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;

  if (items.length === 0) return <EmptyItems />;

  return (
    <div className="space-y-3">
      {items.map(item => {
        const isRunning = running[item.id] !== undefined && running[item.id] !== null;
        const secs = elapsed[item.id] ?? 0;
        const logged = todayMinutes.get(item.id) ?? 0;
        return (
          <div key={item.id} className="flex items-center gap-3 p-3 rounded-xl bg-muted/30">
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium">{item.name}</div>
              <div className="text-xs text-muted-foreground">{logged}min logged today</div>
            </div>
            {isRunning && (
              <div className="text-lg font-mono text-primary font-bold">{fmtSec(secs)}</div>
            )}
            <button onClick={() => isRunning ? stopTimer(item.id) : startTimer(item.id)}
              className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold transition-all ${isRunning ? "bg-destructive/80 hover:bg-destructive text-white" : "bg-primary/20 hover:bg-primary/30 text-primary"}`}
            >
              {isRunning ? "⏹" : "▶"}
            </button>
          </div>
        );
      })}
    </div>
  );
}

// ─── Empty Items Placeholder ───────────────────────────────────────────────

function EmptyItems() {
  return (
    <div className="flex flex-col items-center justify-center py-6 text-center">
      <div className="text-3xl mb-2 opacity-30">📭</div>
      <div className="text-sm text-muted-foreground">No items yet. Add one below.</div>
    </div>
  );
}

// ─── Layout Renderer ───────────────────────────────────────────────────────

function SectionLayoutRenderer({ section, items, completions, trackerId }: {
  section: TrackerSection;
  items: TrackerItem[];
  completions: Completion[];
  trackerId: number;
}) {
  const sectionItems = items.filter(i => i.sectionId === section.id);

  switch (section.layoutType) {
    case "habit_grid": return <HabitGrid items={sectionItems} completions={completions} trackerId={trackerId} />;
    case "checkbox": return <CheckboxLayout items={sectionItems} completions={completions} trackerId={trackerId} />;
    case "progress": return <ProgressLayout items={sectionItems} completions={completions} trackerId={trackerId} />;
    case "notes": return <NotesLayout items={sectionItems} />;
    case "counter": return <CounterLayout items={sectionItems} completions={completions} trackerId={trackerId} />;
    case "streak": return <StreakLayout items={sectionItems} completions={completions} trackerId={trackerId} />;
    case "timer": return <TimerLayout items={sectionItems} completions={completions} trackerId={trackerId} />;
    default: return <HabitGrid items={sectionItems} completions={completions} trackerId={trackerId} />;
  }
}

// ─── Add Item Row ──────────────────────────────────────────────────────────

function AddItemRow({ trackerId, sectionId }: { trackerId: number; sectionId: number }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [targetValue, setTargetValue] = useState("");
  const [unit, setUnit] = useState("");
  const queryClient = useQueryClient();
  const create = useCreateTrackerItem();

  const submit = () => {
    if (!name.trim()) return;
    const data: any = { name: name.trim(), type: "habit" as const, sectionId, position: 0 };
    if (targetValue) data.targetValue = parseFloat(targetValue);
    if (unit) data.unit = unit.trim();
    create.mutate(
      { trackerId, data },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListTrackerItemsQueryKey(trackerId) });
          setName(""); setTargetValue(""); setUnit(""); setOpen(false);
        },
      }
    );
  };

  if (!open) return (
    <Button variant="ghost" size="sm" className="text-muted-foreground gap-2 text-xs h-8 mt-3" onClick={() => setOpen(true)}>
      <Plus className="w-3.5 h-3.5" /> Add item
    </Button>
  );

  return (
    <div className="mt-3 flex items-center gap-2 flex-wrap">
      <Input autoFocus placeholder="Item name…" value={name}
        onChange={e => setName(e.target.value)}
        onKeyDown={e => { if (e.key === "Enter") submit(); if (e.key === "Escape") setOpen(false); }}
        className="h-8 text-sm max-w-[200px]"
      />
      <Input placeholder="Target (optional)" value={targetValue}
        onChange={e => setTargetValue(e.target.value)}
        className="h-8 text-sm w-32"
        type="number"
      />
      <Input placeholder="Unit (optional)" value={unit}
        onChange={e => setUnit(e.target.value)}
        className="h-8 text-sm w-24"
      />
      <Button size="sm" className="h-8 text-xs" onClick={submit} disabled={!name.trim() || create.isPending}>Add</Button>
      <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => setOpen(false)}><X className="w-3.5 h-3.5" /></Button>
    </div>
  );
}

// ─── Section Card ──────────────────────────────────────────────────────────

function SectionCard({
  section,
  items,
  completions,
  trackerId,
  isActive,
  onRef,
}: {
  section: TrackerSection;
  items: TrackerItem[];
  completions: Completion[];
  trackerId: number;
  isActive: boolean;
  onRef: (el: HTMLDivElement | null) => void;
}) {
  const queryClient = useQueryClient();
  const updateSection = useUpdateSection();
  const deleteSection = useDeleteSection();
  const deleteItem = useDeleteTrackerItem();
  const { toast } = useToast();

  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(section.name);
  const [showSettings, setShowSettings] = useState(false);
  const [collapsed, setCollapsed] = useState(section.isCollapsed ?? false);

  const sectionItems = items.filter(i => i.sectionId === section.id);
  const meta = LAYOUT_META[section.layoutType] ?? LAYOUT_META.habit_grid;

  const saveCollapsed = (val: boolean) => {
    setCollapsed(val);
    updateSection.mutate(
      { trackerId, sectionId: section.id, data: { isCollapsed: val } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListSectionsQueryKey(trackerId) }) }
    );
  };

  const saveName = () => {
    if (!editName.trim() || editName === section.name) { setIsEditing(false); return; }
    updateSection.mutate(
      { trackerId, sectionId: section.id, data: { name: editName.trim() } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSectionsQueryKey(trackerId) });
          setIsEditing(false);
        },
      }
    );
  };

  const handleDelete = () => {
    if (!confirm(`Delete section "${section.name}" and all its items?`)) return;
    deleteSection.mutate(
      { trackerId, sectionId: section.id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSectionsQueryKey(trackerId) });
          queryClient.invalidateQueries({ queryKey: getListTrackerItemsQueryKey(trackerId) });
          toast({ title: "Section deleted" });
        },
      }
    );
  };

  const handleDeleteItem = (itemId: number) => {
    deleteItem.mutate(
      { trackerId, itemId },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListTrackerItemsQueryKey(trackerId) }) }
    );
  };

  const handleLayoutChange = (layoutType: string) => {
    updateSection.mutate(
      { trackerId, sectionId: section.id, data: { layoutType: layoutType as any } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListSectionsQueryKey(trackerId) }) }
    );
    setShowSettings(false);
  };

  return (
    <motion.div
      ref={onRef}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-2xl border bg-card transition-all duration-200 ${isActive ? "border-primary/40 shadow-lg shadow-primary/5" : "border-border/60"}`}
    >
      {/* Section Header */}
      <div className="flex items-center gap-3 px-5 py-4">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center text-base flex-shrink-0"
          style={{ backgroundColor: `${section.color}20`, border: `1px solid ${section.color}40` }}>
          {section.icon}
        </div>

        <div className="flex-1 min-w-0">
          {isEditing ? (
            <Input autoFocus value={editName} onChange={e => setEditName(e.target.value)}
              onBlur={saveName}
              onKeyDown={e => { if (e.key === "Enter") saveName(); if (e.key === "Escape") { setEditName(section.name); setIsEditing(false); } }}
              className="h-7 text-sm font-semibold bg-transparent border-b border-primary/50 rounded-none px-0 focus-visible:ring-0"
            />
          ) : (
            <button className="text-sm font-semibold hover:text-primary/80 transition-colors text-left w-full truncate"
              onClick={() => setIsEditing(true)}>
              {section.name}
            </button>
          )}
          <div className="flex items-center gap-1.5 mt-0.5">
            <meta.Icon className="w-3 h-3" style={{ color: meta.color }} />
            <span className="text-[10px] text-muted-foreground">{meta.label}</span>
            <span className="text-[10px] text-muted-foreground">·</span>
            <span className="text-[10px] text-muted-foreground">{sectionItems.length} items</span>
          </div>
        </div>

        <div className="flex items-center gap-1 flex-shrink-0">
          {/* Settings dropdown */}
          <div className="relative">
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
              onClick={() => setShowSettings(p => !p)}>
              <Settings2 className="w-3.5 h-3.5" />
            </Button>
            {showSettings && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setShowSettings(false)} />
                <div className="absolute right-0 top-8 z-20 bg-popover border border-border rounded-xl shadow-xl p-2 w-52">
                  <div className="text-xs font-medium text-muted-foreground px-2 py-1 mb-1">Layout type</div>
                  {Object.entries(LAYOUT_META).map(([key, m]) => (
                    <button key={key} onClick={() => handleLayoutChange(key)}
                      className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-sm text-left hover:bg-muted/60 transition-colors ${section.layoutType === key ? "bg-primary/10 text-primary" : ""}`}
                    >
                      <m.Icon className="w-3.5 h-3.5 flex-shrink-0" style={{ color: m.color }} />
                      {m.label}
                    </button>
                  ))}
                  <div className="border-t border-border/60 mt-2 pt-2">
                    <button onClick={handleDelete}
                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-sm text-left text-destructive hover:bg-destructive/10 transition-colors">
                      <Trash2 className="w-3.5 h-3.5" /> Delete section
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Collapse toggle */}
          <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground"
            onClick={() => saveCollapsed(!collapsed)}>
            {collapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </Button>
        </div>
      </div>

      {/* Section Body */}
      <AnimatePresence>
        {!collapsed && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-4 border-t border-border/40 pt-4">
              <SectionLayoutRenderer section={section} items={items} completions={completions} trackerId={trackerId} />

              {/* Items management (non-notes) */}
              {section.layoutType !== "notes" && (
                <div className="mt-4 pt-3 border-t border-border/30">
                  {sectionItems.length > 0 && (
                    <div className="space-y-1 mb-2">
                      {sectionItems.map(item => (
                        <div key={item.id} className="flex items-center justify-between text-xs text-muted-foreground group py-0.5">
                          <span className="truncate">{item.name}{item.unit ? ` (${item.unit})` : ""}{item.targetValue ? ` — target: ${item.targetValue}` : ""}</span>
                          <Button variant="ghost" size="sm" className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100"
                            onClick={() => handleDeleteItem(item.id)}>
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                  <AddItemRow trackerId={trackerId} sectionId={section.id} />
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ─── Sortable Sidebar Item ─────────────────────────────────────────────────

function SortableSidebarItem({ section, isActive, onClick }: {
  section: TrackerSection;
  isActive: boolean;
  onClick: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: section.id });

  return (
    <div ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.5 : 1 }}
      className={`flex items-center gap-2 px-3 py-2 rounded-xl cursor-pointer transition-all group ${isActive ? "bg-primary/15 text-primary" : "hover:bg-muted/50 text-muted-foreground hover:text-foreground"}`}
      onClick={onClick}
    >
      <div {...attributes} {...listeners} className="cursor-grab opacity-0 group-hover:opacity-40 hover:!opacity-80 flex-shrink-0">
        <GripVertical className="w-3 h-3" />
      </div>
      <span className="text-sm flex-shrink-0">{section.icon}</span>
      <span className="text-sm flex-1 truncate font-medium">{section.name}</span>
      {(section.itemCount ?? 0) > 0 && (
        <span className="text-[10px] bg-muted/60 rounded-full px-1.5 py-0.5 flex-shrink-0">{section.itemCount}</span>
      )}
    </div>
  );
}

// ─── Add Section Form ──────────────────────────────────────────────────────

function AddSectionForm({ trackerId, onDone }: { trackerId: number; onDone: () => void }) {
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("📋");
  const [color, setColor] = useState("#9333ea");
  const [layoutType, setLayoutType] = useState<string>("habit_grid");
  const queryClient = useQueryClient();
  const create = useCreateSection();

  const submit = () => {
    if (!name.trim()) return;
    create.mutate(
      { trackerId, data: { name: name.trim(), icon, color, layoutType: layoutType as any } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSectionsQueryKey(trackerId) });
          onDone();
        },
      }
    );
  };

  return (
    <div className="rounded-2xl border border-primary/30 bg-card p-5 space-y-4">
      <div className="flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-primary" />
        <span className="font-semibold text-sm">New Section</span>
      </div>

      <Input autoFocus placeholder="Section name…" value={name}
        onChange={e => setName(e.target.value)}
        onKeyDown={e => { if (e.key === "Enter") submit(); if (e.key === "Escape") onDone(); }}
        className="h-9"
      />

      <div>
        <div className="text-xs text-muted-foreground mb-2">Icon</div>
        <div className="flex flex-wrap gap-1.5">
          {SECTION_ICONS.map(em => (
            <button key={em} onClick={() => setIcon(em)}
              className={`w-8 h-8 rounded-lg text-base transition-all ${icon === em ? "bg-primary/20 ring-2 ring-primary/50" : "bg-muted/40 hover:bg-muted/60"}`}
            >{em}</button>
          ))}
        </div>
      </div>

      <div>
        <div className="text-xs text-muted-foreground mb-2">Color</div>
        <div className="flex gap-2">
          {SECTION_COLORS.map(c => (
            <button key={c} onClick={() => setColor(c)}
              className={`w-6 h-6 rounded-full transition-all ${color === c ? "ring-2 ring-offset-2 ring-offset-card ring-white/60 scale-110" : "hover:scale-105"}`}
              style={{ backgroundColor: c }}
            />
          ))}
        </div>
      </div>

      <div>
        <div className="text-xs text-muted-foreground mb-2">Layout type</div>
        <div className="grid grid-cols-2 gap-1.5">
          {Object.entries(LAYOUT_META).map(([key, m]) => (
            <button key={key} onClick={() => setLayoutType(key)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-left transition-all ${layoutType === key ? "bg-primary/15 text-primary border border-primary/30" : "bg-muted/30 hover:bg-muted/50 border border-transparent"}`}
            >
              <m.Icon className="w-3.5 h-3.5 flex-shrink-0" style={{ color: m.color }} />
              {m.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-2 pt-1">
        <Button size="sm" className="flex-1" onClick={submit} disabled={!name.trim() || create.isPending}>
          Create section
        </Button>
        <Button size="sm" variant="ghost" onClick={onDone}>Cancel</Button>
      </div>
    </div>
  );
}

// ─── Overview Panel ────────────────────────────────────────────────────────

function OverviewPanel({ sections, items, completions, trackerId }: {
  sections: TrackerSection[];
  items: TrackerItem[];
  completions: Completion[];
  trackerId: number;
}) {
  const todayStr = today();
  const doneToday = new Set(completions.filter(c => c.date === todayStr && c.completed).map(c => c.itemId));

  if (sections.length === 0) return null;

  return (
    <div className="grid grid-cols-2 gap-3">
      {sections.map(section => {
        const sectionItems = items.filter(i => i.sectionId === section.id);
        const doneCount = sectionItems.filter(i => doneToday.has(i.id)).length;
        const pct = sectionItems.length > 0 ? Math.round((doneCount / sectionItems.length) * 100) : 0;
        const meta = LAYOUT_META[section.layoutType] ?? LAYOUT_META.habit_grid;

        return (
          <div key={section.id} className="rounded-xl border border-border/50 bg-muted/20 p-3">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-base">{section.icon}</span>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{section.name}</div>
                <div className="flex items-center gap-1">
                  <meta.Icon className="w-3 h-3" style={{ color: meta.color }} />
                  <span className="text-[10px] text-muted-foreground">{meta.label}</span>
                </div>
              </div>
              <div className="text-sm font-bold" style={{ color: section.color }}>{pct}%</div>
            </div>
            <div className="h-1.5 rounded-full bg-muted/60 overflow-hidden">
              <div className="h-full rounded-full transition-all duration-500"
                style={{ width: `${pct}%`, backgroundColor: section.color }} />
            </div>
            <div className="text-xs text-muted-foreground mt-1">{doneCount}/{sectionItems.length} items today</div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────────────

export default function TrackerDetail() {
  const [, params] = useRoute("/trackers/:id");
  const id = Number(params?.id);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [activeSectionId, setActiveSectionId] = useState<number | "overview" | null>("overview");
  const [addingSection, setAddingSection] = useState(false);
  const sectionRefs = useRef<Record<number, HTMLDivElement | null>>({});

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const { data: tracker, isLoading: trackerLoading } = useGetTracker(id);
  const { data: sections = [], isLoading: sectionsLoading } = useListSections(id);
  const { data: items = [], isLoading: itemsLoading } = useListTrackerItems(id);
  const { data: completions = [] } = useGetCompletionLog(id);

  const reorderSections = useReorderSections();
  const createShare = useCreateShareLink();
  const deleteShare = useDeleteShareLink();

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const oldIndex = sections.findIndex(s => s.id === active.id);
    const newIndex = sections.findIndex(s => s.id === over.id);
    const reordered = arrayMove(sections, oldIndex, newIndex);

    reorderSections.mutate(
      { trackerId: id, data: { order: reordered.map(s => s.id) } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getListSectionsQueryKey(id) }) }
    );
  }, [sections, id, reorderSections, queryClient]);

  const scrollToSection = (sectionId: number) => {
    setActiveSectionId(sectionId);
    setTimeout(() => {
      sectionRefs.current[sectionId]?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 50);
  };

  const handleCreateShare = () => {
    createShare.mutate(
      { trackerId: id, data: { mode: "view" } },
      {
        onSuccess: link => {
          const url = `${window.location.origin}/share/${link.token}`;
          navigator.clipboard.writeText(url);
          toast({ title: "Share link copied!", description: url });
          queryClient.invalidateQueries({ queryKey: getGetTrackerQueryKey(id) });
        },
      }
    );
  };

  const handleDeleteShare = () => {
    if (!tracker?.shareToken) return;
    deleteShare.mutate({ trackerId: id }, {
      onSuccess: () => {
        toast({ title: "Share link removed" });
        queryClient.invalidateQueries({ queryKey: getGetTrackerQueryKey(id) });
      },
    });
  };

  const loading = trackerLoading || sectionsLoading || itemsLoading;

  const todayStr = today();
  const todayDone = new Set(completions.filter(c => c.date === todayStr && c.completed).map(c => c.itemId));
  const totalItems = items.length;
  const doneToday = items.filter(i => todayDone.has(i.id)).length;
  const overallPct = totalItems > 0 ? Math.round((doneToday / totalItems) * 100) : 0;

  return (
    <div className="space-y-5">
      <Link href="/trackers">
        <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground -ml-2">
          <ArrowLeft className="w-4 h-4" /> Trackers
        </Button>
      </Link>

      {loading ? (
        <div className="space-y-4">
          <Skeleton className="h-16 w-2/3 rounded-xl" />
          <Skeleton className="h-96 rounded-2xl" />
        </div>
      ) : !tracker ? (
        <div className="text-muted-foreground">Tracker not found.</div>
      ) : (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
          {/* ── Tracker Header ── */}
          <div className="rounded-2xl border border-border/60 bg-card px-6 py-5">
            <div className="flex items-start justify-between flex-wrap gap-3">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
                  style={{ backgroundColor: `${tracker.color}20`, border: `1px solid ${tracker.color}40` }}>
                  {tracker.icon}
                </div>
                <div>
                  <h1 className="text-2xl font-bold">{tracker.title}</h1>
                  {tracker.description && <p className="text-sm text-muted-foreground mt-0.5">{tracker.description}</p>}
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    <Badge variant="outline" className="text-xs capitalize">{tracker.mode}</Badge>
                    {tracker.category && <Badge variant="outline" className="text-xs">{tracker.category}</Badge>}
                    {(tracker.currentStreak ?? 0) > 0 && (
                      <Badge className="bg-orange-500/10 text-orange-400 border-orange-500/20 text-xs">
                        <Flame className="w-3 h-3 mr-1" />{tracker.currentStreak}d streak
                      </Badge>
                    )}
                    <span className="text-xs text-muted-foreground">{sections.length} sections · {totalItems} items · {overallPct}% today</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                {tracker.shareToken ? (
                  <>
                    <Button variant="outline" size="sm" className="gap-2 text-xs" onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}/share/${tracker.shareToken}`);
                      toast({ title: "Copied!" });
                    }}>
                      <Copy className="w-3.5 h-3.5" /> Copy link
                    </Button>
                    <Button variant="ghost" size="sm" className="text-xs text-muted-foreground" onClick={handleDeleteShare}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </>
                ) : (
                  <Button variant="outline" size="sm" className="gap-2 text-xs" onClick={handleCreateShare} disabled={createShare.isPending}>
                    <LinkIcon className="w-3.5 h-3.5" /> Share
                  </Button>
                )}
                <Link href={`/trackers/analytics`}>
                  <Button variant="outline" size="sm" className="gap-2 text-xs">
                    <BarChart3 className="w-3.5 h-3.5" /> Analytics
                  </Button>
                </Link>
                <Link href={`/trackers/${id}/edit`}>
                  <Button variant="outline" size="sm" className="gap-2 text-xs">
                    <Pencil className="w-3.5 h-3.5" /> Edit
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* ── Two-column layout ── */}
          <div className="flex gap-5 items-start">
            {/* Sidebar */}
            <div className="w-52 flex-shrink-0 space-y-1 sticky top-4">
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3 mb-2">Sections</div>

              {/* Overview */}
              <button
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all ${activeSectionId === "overview" ? "bg-primary/15 text-primary" : "hover:bg-muted/50 text-muted-foreground hover:text-foreground"}`}
                onClick={() => setActiveSectionId("overview")}
              >
                <LayoutGrid className="w-3.5 h-3.5 flex-shrink-0" />
                <span className="font-medium">Overview</span>
              </button>

              {/* Draggable section list */}
              <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                <SortableContext items={sections.map(s => s.id)} strategy={verticalListSortingStrategy}>
                  {sections.map(s => (
                    <SortableSidebarItem key={s.id} section={s}
                      isActive={activeSectionId === s.id}
                      onClick={() => scrollToSection(s.id)}
                    />
                  ))}
                </SortableContext>
              </DndContext>

              <div className="pt-2">
                <button
                  className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-muted-foreground hover:text-primary hover:bg-primary/10 transition-all"
                  onClick={() => { setAddingSection(true); setActiveSectionId(null); }}
                >
                  <Plus className="w-3.5 h-3.5" /> Add section
                </button>
              </div>
            </div>

            {/* Main content */}
            <div className="flex-1 min-w-0 space-y-4">
              {/* Overview panel */}
              {activeSectionId === "overview" && sections.length > 0 && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-2xl border border-border/60 bg-card p-5">
                  <h2 className="font-semibold mb-4 flex items-center gap-2">
                    <LayoutGrid className="w-4 h-4 text-primary" /> Dashboard Overview
                  </h2>
                  <OverviewPanel sections={sections} items={items} completions={completions} trackerId={id} />
                </motion.div>
              )}

              {/* Empty state */}
              {sections.length === 0 && !addingSection && (
                <div className="rounded-2xl border border-dashed border-border/60 bg-card p-10 text-center">
                  <div className="text-4xl mb-3">🗂️</div>
                  <h3 className="font-semibold mb-1">No sections yet</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Sections let you organize different habits, goals, or activities inside one tracker.
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center mb-4">
                    {[
                      { name: "Study", icon: "📚", color: "#9333ea", layoutType: "habit_grid" },
                      { name: "Fitness", icon: "💪", color: "#f97316", layoutType: "streak" },
                      { name: "Finance", icon: "💰", color: "#10b981", layoutType: "progress" },
                      { name: "Mental Health", icon: "🧠", color: "#3b82f6", layoutType: "checkbox" },
                      { name: "Daily Routine", icon: "☀️", color: "#f59e0b", layoutType: "checklist" },
                    ].map(t => (
                      <button key={t.name}
                        className="px-3 py-1.5 rounded-lg bg-muted/50 hover:bg-primary/10 hover:text-primary text-sm transition-colors border border-border/50"
                        onClick={() => setAddingSection(true)}
                      >
                        {t.icon} {t.name}
                      </button>
                    ))}
                  </div>
                  <Button onClick={() => setAddingSection(true)} className="gap-2">
                    <Plus className="w-4 h-4" /> Create your first section
                  </Button>
                </div>
              )}

              {/* Add section form */}
              {addingSection && (
                <AddSectionForm trackerId={id} onDone={() => { setAddingSection(false); setActiveSectionId("overview"); }} />
              )}

              {/* Section cards */}
              {sections.map(section => (
                <SectionCard
                  key={section.id}
                  section={section}
                  items={items}
                  completions={completions}
                  trackerId={id}
                  isActive={activeSectionId === section.id}
                  onRef={el => { sectionRefs.current[section.id] = el; }}
                />
              ))}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
