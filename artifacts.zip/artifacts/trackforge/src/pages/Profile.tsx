import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useUser } from "@clerk/react";
import { useGetMe, useUpdateMe } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { User } from "lucide-react";

export default function Profile() {
  const { user: clerkUser } = useUser();
  const { data: profile, isLoading } = useGetMe();
  const update = useUpdateMe();
  const { toast } = useToast();

  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName ?? clerkUser?.fullName ?? "");
      setBio(profile.bio ?? "");
    }
  }, [profile, clerkUser]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    update.mutate(
      { data: { displayName, bio } },
      {
        onSuccess: () => toast({ title: "Profile updated!" }),
        onError: () => toast({ title: "Failed to update", variant: "destructive" }),
      }
    );
  };

  const avatarUrl = clerkUser?.imageUrl ?? profile?.avatarUrl;
  const joinedDate = profile?.createdAt
    ? new Date(profile.createdAt).toLocaleDateString("en-US", { month: "long", year: "numeric" })
    : null;

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold">Profile</h1>
        <p className="text-muted-foreground text-sm mt-0.5">Manage your account details.</p>
      </motion.div>

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-20 rounded-2xl" />
          <Skeleton className="h-48 rounded-2xl" />
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="space-y-5"
        >
          {/* Avatar / identity */}
          <div className="rounded-2xl border border-border/60 bg-card p-5 flex items-center gap-4">
            {avatarUrl ? (
              <img
                src={avatarUrl}
                alt="avatar"
                className="w-16 h-16 rounded-full object-cover border-2 border-primary/30"
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-primary/10 border-2 border-primary/20 flex items-center justify-center">
                <User className="w-8 h-8 text-primary" />
              </div>
            )}
            <div>
              <div className="font-semibold text-lg">
                {profile?.displayName || clerkUser?.fullName || clerkUser?.username || "User"}
              </div>
              <div className="text-sm text-muted-foreground">
                {clerkUser?.primaryEmailAddress?.emailAddress}
              </div>
              {joinedDate && (
                <div className="text-xs text-muted-foreground/60 mt-0.5">Member since {joinedDate}</div>
              )}
            </div>
          </div>

          {/* Edit form */}
          <form onSubmit={handleSubmit} className="rounded-2xl border border-border/60 bg-card p-6 space-y-5">
            <div className="space-y-1.5">
              <Label>Display name</Label>
              <Input
                placeholder="Your name"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
              />
            </div>

            <div className="space-y-1.5">
              <Label>Bio</Label>
              <Textarea
                placeholder="Tell us a bit about yourself…"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                rows={3}
              />
            </div>

            <Button
              type="submit"
              className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20"
              disabled={update.isPending}
            >
              {update.isPending ? "Saving…" : "Save Changes"}
            </Button>
          </form>

          {/* Clerk managed settings note */}
          <div className="rounded-xl border border-border/40 bg-muted/20 p-4 text-sm text-muted-foreground">
            Email and password settings are managed through your account provider.
          </div>
        </motion.div>
      )}
    </div>
  );
}
