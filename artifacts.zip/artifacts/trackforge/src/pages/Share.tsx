import { motion } from "framer-motion";
import { useRoute } from "wouter";
import { useGetSharedTracker } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle2, Circle, Flame, Sparkles } from "lucide-react";
import type { TrackerItem, Completion } from "@workspace/api-client-react";

function PublicHabitGrid({
  items,
  completions,
}: {
  items: TrackerItem[];
  completions: Completion[];
}) {
  const completionMap = new Map<string, boolean>();
  completions.forEach((c) => {
    completionMap.set(`${c.itemId}-${c.date}`, c.completed);
  });

  const todayStr = new Date().toISOString().split("T")[0];
  const last14 = Array.from({ length: 14 }).map((_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (13 - i));
    return d.toISOString().split("T")[0];
  });

  if (items.length === 0) {
    return <div className="text-muted-foreground text-sm text-center py-8">No items in this tracker.</div>;
  }

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[560px]">
        <div className="flex items-center mb-2 ml-[180px] gap-1">
          {last14.map((d) => (
            <div
              key={d}
              className={`w-8 text-center text-[10px] flex-shrink-0 ${
                d === todayStr ? "text-primary font-semibold" : "text-muted-foreground"
              }`}
            >
              {new Date(d + "T12:00:00").toLocaleDateString("en-US", { weekday: "narrow" })}
            </div>
          ))}
        </div>
        {items.map((item) => (
          <div key={item.id} className="flex items-center gap-1 mb-1.5">
            <div className="w-[172px] flex-shrink-0 pr-2 text-sm text-muted-foreground truncate text-right">
              {item.name}
            </div>
            {last14.map((d) => {
              const done = completionMap.get(`${item.id}-${d}`) ?? false;
              const isToday = d === todayStr;
              return (
                <div
                  key={d}
                  className={`w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0 ${
                    done
                      ? "bg-primary/80"
                      : isToday
                      ? "bg-muted/60 border border-primary/30"
                      : "bg-muted/30 border border-border/30"
                  }`}
                >
                  {done ? (
                    <CheckCircle2 className="w-4 h-4 text-white" />
                  ) : (
                    <Circle className={`w-3.5 h-3.5 ${isToday ? "text-primary/50" : "text-muted-foreground/30"}`} />
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Share() {
  const [, params] = useRoute("/share/:token");
  const token = params?.token ?? "";

  const { data, isLoading, isError } = useGetSharedTracker(token);

  const tracker = data?.tracker;
  const items = data?.items ?? [];
  const completions = data?.completions ?? [];

  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Minimal nav */}
      <nav className="h-14 flex items-center px-6 border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
          </div>
          <span className="font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-400">
            TrackForge
          </span>
        </div>
        <a
          href={basePath || "/"}
          className="ml-auto text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          Create your own →
        </a>
      </nav>

      <div className="max-w-3xl mx-auto px-6 py-12">
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-16 w-2/3 rounded-2xl" />
            <Skeleton className="h-64 rounded-2xl" />
          </div>
        ) : isError || !tracker ? (
          <div className="text-center py-24">
            <div className="text-4xl mb-4">🔒</div>
            <h2 className="text-xl font-semibold mb-2">Tracker not found</h2>
            <p className="text-muted-foreground">This share link may have expired or been removed.</p>
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            {/* Tracker header */}
            <div className="flex items-center gap-4">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0"
                style={{ backgroundColor: `${tracker.color}20`, border: `1px solid ${tracker.color}40` }}
              >
                {tracker.icon}
              </div>
              <div>
                <h1 className="text-2xl font-bold">{tracker.title}</h1>
                {tracker.description && (
                  <p className="text-muted-foreground text-sm mt-0.5">{tracker.description}</p>
                )}
                <div className="flex items-center gap-2 mt-1.5">
                  <Badge variant="outline" className="text-xs capitalize">{tracker.mode}</Badge>
                  {tracker.category && (
                    <Badge variant="outline" className="text-xs">{tracker.category}</Badge>
                  )}
                  {(tracker.currentStreak ?? 0) > 0 && (
                    <Badge className="bg-orange-500/10 text-orange-400 border-orange-500/20 text-xs">
                      <Flame className="w-3 h-3 mr-1" />{tracker.currentStreak}d streak
                    </Badge>
                  )}
                </div>
              </div>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-4">
              {[
                { label: "Items", value: items.length },
                { label: "Today", value: `${Math.round(tracker.todayCompletionPct ?? 0)}%` },
                { label: "Streak", value: `${tracker.currentStreak ?? 0}d` },
              ].map(({ label, value }) => (
                <div key={label} className="rounded-xl border border-border/60 bg-card p-4 text-center">
                  <div className="text-xl font-bold text-primary">{value}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{label}</div>
                </div>
              ))}
            </div>

            {/* Habit grid */}
            <div className="rounded-2xl border border-border/60 bg-card p-5">
              <h2 className="font-semibold mb-5">Habit Grid — Last 14 Days</h2>
              <PublicHabitGrid items={items} completions={completions} />
            </div>

            <p className="text-center text-xs text-muted-foreground pt-2">
              Shared via{" "}
              <a href={basePath || "/"} className="text-primary hover:underline">
                TrackForge
              </a>
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
}
