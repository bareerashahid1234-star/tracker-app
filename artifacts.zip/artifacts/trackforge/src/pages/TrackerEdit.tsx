import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link, useRoute, useLocation } from "wouter";
import { ArrowLeft, Check } from "lucide-react";
import {
  useGetTracker,
  useUpdateTracker,
  getGetTrackerQueryKey,
  getListTrackersQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const COLORS = [
  "#9333ea", "#6366f1", "#3b82f6", "#06b6d4",
  "#10b981", "#f59e0b", "#ef4444", "#ec4899",
];
const ICONS = ["🎯", "🏋️", "📚", "💻", "🧘", "🌿", "💪", "✍️", "🎨", "🎵", "🚀", "⚡", "🔥", "💡", "🏆", "🌟"];

export default function TrackerEdit() {
  const [, params] = useRoute("/trackers/:id/edit");
  const id = Number(params?.id);
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const update = useUpdateTracker();

  const { data: tracker, isLoading } = useGetTracker(id);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [color, setColor] = useState(COLORS[0]);
  const [icon, setIcon] = useState(ICONS[0]);
  const [mode, setMode] = useState<"daily" | "weekly" | "monthly">("daily");
  const [isPinned, setIsPinned] = useState(false);

  useEffect(() => {
    if (tracker) {
      setTitle(tracker.title);
      setDescription(tracker.description ?? "");
      setCategory(tracker.category ?? "");
      setColor(tracker.color);
      setIcon(tracker.icon);
      setMode(tracker.mode as typeof mode);
      setIsPinned(tracker.isPinned ?? false);
    }
  }, [tracker]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    update.mutate(
      { id, data: { title: title.trim(), description, category, color, icon, mode, isPinned } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetTrackerQueryKey(id) });
          queryClient.invalidateQueries({ queryKey: getListTrackersQueryKey() });
          navigate(`/trackers/${id}`);
        },
      }
    );
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <Link href={`/trackers/${id}`}>
          <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground -ml-2 mb-4">
            <ArrowLeft className="w-4 h-4" /> Back to tracker
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Edit Tracker</h1>
        <p className="text-muted-foreground text-sm mt-1">Update your tracker settings.</p>
      </motion.div>

      {isLoading ? (
        <div className="space-y-4">
          {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 rounded-xl" />)}
        </div>
      ) : (
        <motion.form
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          onSubmit={handleSubmit}
          className="rounded-2xl border border-border/60 bg-card p-6 space-y-5"
        >
          <div className="space-y-1.5">
            <Label>Title *</Label>
            <Input
              placeholder="e.g. Morning Routine"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>

          <div className="space-y-1.5">
            <Label>Description</Label>
            <Textarea
              placeholder="What is this tracker for?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Category</Label>
            <Input
              placeholder="e.g. Health, Work, Learning"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Tracking mode</Label>
            <Select value={mode} onValueChange={(v) => setMode(v as typeof mode)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily — track every day</SelectItem>
                <SelectItem value="weekly">Weekly — track each week</SelectItem>
                <SelectItem value="monthly">Monthly — track each month</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>Icon</Label>
            <div className="flex flex-wrap gap-2">
              {ICONS.map((em) => (
                <button
                  key={em}
                  type="button"
                  onClick={() => setIcon(em)}
                  className={`w-10 h-10 rounded-lg text-xl flex items-center justify-center transition-all ${
                    icon === em
                      ? "bg-primary/20 border border-primary/60 shadow-sm"
                      : "bg-muted/40 border border-border/40 hover:bg-muted"
                  }`}
                >
                  {em}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Color</Label>
            <div className="flex gap-2 flex-wrap">
              {COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className="w-8 h-8 rounded-full border-2 transition-all flex items-center justify-center"
                  style={{
                    backgroundColor: c,
                    borderColor: color === c ? "white" : "transparent",
                    boxShadow: color === c ? `0 0 0 2px ${c}` : "none",
                  }}
                >
                  {color === c && <Check className="w-4 h-4 text-white" />}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="isPinned"
              checked={isPinned}
              onChange={(e) => setIsPinned(e.target.checked)}
              className="w-4 h-4 accent-primary"
            />
            <Label htmlFor="isPinned" className="cursor-pointer">Pin to dashboard</Label>
          </div>

          <div className="flex gap-3 pt-1">
            <Button
              type="submit"
              className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20"
              disabled={!title.trim() || update.isPending}
            >
              {update.isPending ? "Saving…" : "Save Changes"}
            </Button>
            <Link href={`/trackers/${id}`}>
              <Button type="button" variant="outline">Cancel</Button>
            </Link>
          </div>
        </motion.form>
      )}
    </div>
  );
}
