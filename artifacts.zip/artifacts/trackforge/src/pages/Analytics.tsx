import { useState } from "react";
import { motion } from "framer-motion";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  Area,
  AreaChart,
} from "recharts";
import { useListTrackers, useGetTrackerAnalytics } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Flame, TrendingUp, Target, Calendar } from "lucide-react";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4 } },
};

function CustomTooltip({ active, payload, label }: any) {
  if (active && payload?.length) {
    return (
      <div className="bg-card border border-border rounded-lg px-3 py-2 text-sm shadow-xl">
        <div className="text-muted-foreground mb-1">{label}</div>
        {payload.map((p: any) => (
          <div key={p.name} className="font-medium" style={{ color: p.color }}>
            {Math.round(p.value)}%
          </div>
        ))}
      </div>
    );
  }
  return null;
}

export default function Analytics() {
  const { data: trackers = [], isLoading: trackersLoading } = useListTrackers();
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const trackerId = selectedId ?? trackers[0]?.id ?? 0;
  const { data: analytics, isLoading: analyticsLoading } = useGetTrackerAnalytics(trackerId);

  const weeklyData = (analytics?.weeklyData ?? []).map((d) => ({
    ...d,
    label: new Date(d.date + "T12:00:00").toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" }),
  }));
  const monthlyData = (analytics?.monthlyData ?? []).map((d) => ({
    ...d,
    label: new Date(d.date + "T12:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" }),
  }));

  return (
    <motion.div initial="hidden" animate="show" variants={container} className="space-y-8">
      {/* Header */}
      <motion.div variants={item} className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold">Analytics</h1>
          <p className="text-muted-foreground text-sm mt-0.5">Dive into your completion patterns and streaks.</p>
        </div>
        {trackersLoading ? (
          <Skeleton className="h-9 w-48 rounded-lg" />
        ) : (
          <Select
            value={String(trackerId)}
            onValueChange={(v) => setSelectedId(Number(v))}
          >
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select tracker" />
            </SelectTrigger>
            <SelectContent>
              {trackers.map((t) => (
                <SelectItem key={t.id} value={String(t.id)}>
                  {t.icon} {t.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </motion.div>

      {/* Stat cards */}
      {analyticsLoading ? (
        <motion.div variants={item} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
        </motion.div>
      ) : analytics ? (
        <motion.div variants={item} className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Current streak", value: `${analytics.currentStreak}d`, icon: Flame, color: "text-orange-400 bg-orange-500/10" },
            { label: "Longest streak", value: `${analytics.longestStreak}d`, icon: TrendingUp, color: "text-green-400 bg-green-500/10" },
            { label: "Total completions", value: analytics.totalCompletions, icon: Target, color: "text-primary bg-primary/10" },
            { label: "Completion rate", value: `${Math.round(analytics.completionRate)}%`, icon: Calendar, color: "text-purple-400 bg-purple-500/10" },
          ].map(({ label, value, icon: Icon, color }) => (
            <div key={label} className="rounded-2xl border border-border/60 bg-card p-5 flex flex-col gap-3">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${color}`}>
                <Icon className="w-4.5 h-4.5" />
              </div>
              <div>
                <div className="text-2xl font-bold">{value}</div>
                <div className="text-sm text-muted-foreground">{label}</div>
              </div>
            </div>
          ))}
        </motion.div>
      ) : null}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly bar chart */}
        <motion.div variants={item} className="rounded-2xl border border-border/60 bg-card p-5">
          <h2 className="font-semibold mb-5">Last 7 Days</h2>
          {analyticsLoading ? (
            <Skeleton className="h-48" />
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={weeklyData} barCategoryGap="30%">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(240 6% 16%)" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fill: "hsl(240 5% 65%)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  domain={[0, 100]}
                  tick={{ fill: "hsl(240 5% 65%)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => `${v}%`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar
                  dataKey="completionPct"
                  fill="hsl(270 70% 60%)"
                  radius={[4, 4, 0, 0]}
                  name="Completion"
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </motion.div>

        {/* Monthly area chart */}
        <motion.div variants={item} className="rounded-2xl border border-border/60 bg-card p-5">
          <h2 className="font-semibold mb-5">Last 30 Days</h2>
          {analyticsLoading ? (
            <Skeleton className="h-48" />
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={monthlyData}>
                <defs>
                  <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(270 70% 60%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(270 70% 60%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(240 6% 16%)" vertical={false} />
                <XAxis
                  dataKey="label"
                  tick={{ fill: "hsl(240 5% 65%)", fontSize: 10 }}
                  axisLine={false}
                  tickLine={false}
                  interval={6}
                />
                <YAxis
                  domain={[0, 100]}
                  tick={{ fill: "hsl(240 5% 65%)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => `${v}%`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="completionPct"
                  stroke="hsl(270 70% 60%)"
                  strokeWidth={2}
                  fill="url(#areaGrad)"
                  name="Completion"
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </motion.div>
      </div>

      {/* All trackers overview */}
      {trackers.length > 0 && (
        <motion.div variants={item} className="rounded-2xl border border-border/60 bg-card p-5">
          <h2 className="font-semibold mb-4">All Trackers Overview</h2>
          <div className="space-y-3">
            {trackers.map((t) => (
              <div key={t.id} className="flex items-center gap-4">
                <div className="w-7 h-7 text-lg flex items-center justify-center flex-shrink-0">{t.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium truncate">{t.title}</span>
                    <div className="flex items-center gap-2 ml-2 flex-shrink-0">
                      {(t.currentStreak ?? 0) > 0 && (
                        <Badge className="bg-orange-500/10 text-orange-400 border-orange-500/20 text-xs">
                          🔥{t.currentStreak}d
                        </Badge>
                      )}
                      <span className="text-xs text-muted-foreground">{Math.round(t.todayCompletionPct ?? 0)}%</span>
                    </div>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${t.todayCompletionPct ?? 0}%`,
                        backgroundColor: t.color,
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
