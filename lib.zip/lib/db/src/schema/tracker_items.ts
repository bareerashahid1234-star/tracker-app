import { pgTable, text, serial, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { trackersTable } from "./trackers";
import { trackerSectionsTable } from "./tracker_sections";

export const trackerItemsTable = pgTable("tracker_items", {
  id: serial("id").primaryKey(),
  trackerId: integer("tracker_id").notNull().references(() => trackersTable.id, { onDelete: "cascade" }),
  sectionId: integer("section_id").references(() => trackerSectionsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  type: text("type").notNull().default("habit"),
  description: text("description"),
  targetValue: real("target_value"),
  unit: text("unit"),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTrackerItemSchema = createInsertSchema(trackerItemsTable).omit({ id: true, createdAt: true });
export type InsertTrackerItem = z.infer<typeof insertTrackerItemSchema>;
export type TrackerItem = typeof trackerItemsTable.$inferSelect;
