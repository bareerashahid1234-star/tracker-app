import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { trackersTable } from "./trackers";

export const trackerSectionsTable = pgTable("tracker_sections", {
  id: serial("id").primaryKey(),
  trackerId: integer("tracker_id").notNull().references(() => trackersTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  icon: text("icon").notNull().default("📋"),
  color: text("color").notNull().default("#9333ea"),
  layoutType: text("layout_type").notNull().default("habit_grid"),
  position: integer("position").notNull().default(0),
  isCollapsed: boolean("is_collapsed").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertTrackerSectionSchema = createInsertSchema(trackerSectionsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertTrackerSection = z.infer<typeof insertTrackerSectionSchema>;
export type TrackerSection = typeof trackerSectionsTable.$inferSelect;
