import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const trackersTable = pgTable("trackers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category"),
  color: text("color").notNull().default("#8B5CF6"),
  icon: text("icon").notNull().default("⚡"),
  mode: text("mode").notNull().default("daily"),
  isPinned: boolean("is_pinned").notNull().default(false),
  shareToken: text("share_token"),
  shareLinkMode: text("share_link_mode"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertTrackerSchema = createInsertSchema(trackersTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertTracker = z.infer<typeof insertTrackerSchema>;
export type Tracker = typeof trackersTable.$inferSelect;
